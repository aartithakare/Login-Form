import React, { useState } from "react";
import ImgR from "./side-img";
import { useNavigate } from "react-router-dom";

function LogIn(){
    const history = useNavigate();
    const[inputVal, setInputVal] = useState({
        email: " ",
        password: " ",
    })
 const[data, setData] = useState([])
    const getData =(e)=>{
    e.preventDefault();
       console.log(e.target.value)
       const name = e.target.name;
       const value = e.target.value;

       setInputVal(()=>{ 
        return{
            ...inputVal[name]= value
        }})
}
const addData = (e) => {
    e.preventDefault();

    const getuserArr = localStorage.getItem("useryoutube");
    console.log(getuserArr);

    const { email, password } = inputVal;
    if (email === "") {
        alert('email field is requred');
    
    } else if (password === "") {
        alert('password field is requred');
    } else {

        if (getuserArr && getuserArr.length) {
            const userdata = JSON.parse(getuserArr);
            const userlogin = userdata.filter((el, k) => {
                return el.email === email && el.password === password
            });

            if (userlogin.length === 0) {
                alert("invalid details")
            } else {
                console.log("user login succesfulyy");
                localStorage.setItem("user_login", JSON.stringify(getuserArr));
                history("/details")
              }
        }
    }

}
    return(
        <>
        <div className="container">
            <div className="row">
               <div className="col-md-6">
                 <form className="mt-5 mb-5">
                 <h2 className="pb-3">Login Form</h2>

               <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="email" className="form-control" name="email" 
                    placeholder="Email" onChange={getData}/>
                    </div>
                </div>

                <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="password" className="form-control" name="password" 
                    placeholder="Password" onChange={getData}/>
                    </div>
                </div>
             
              <div className="form-group row pt-3">
                    <div className="col-sm-12">
                    <button type="submit" className="btn btn-primary btn_clr" onClick={addData}>Log in</button>
                    </div>
                </div>
          
          </form>
          <p>If you are Not already register <span>Sign Up</span></p>
        </div>

        <div className="col-md-6">
            <ImgR />
      </div>
                
      </div>
    </div>
        </>
    )
}

export default LogIn