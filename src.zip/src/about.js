import React from "react";

function About(){
    return(
        <>Hello About</>
    )
}

export default About
