import React from "react";

function Details(){
  return(
    <>
      <h1>Details</h1>
    </>
  )
}

export default Details