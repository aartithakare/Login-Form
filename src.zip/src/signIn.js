import React, { useDeferredValue, useState } from "react";
import ImgR from "./side-img";
import { NavLink } from "react-router-dom";
import LogIn from "./logIn";

function SignUp(){
    const[inputVal, setInputVal] = useState({
        username: " ",
        email: " ",
        phone: " ",
        date: " ",
        password: " ",
    })
 const[data, setData] = useState([])

    const getData =(e)=>{
    e.preventDefault();
       console.log(e.target.value)
       const name = e.target.name;
       const value = e.target.value;

       setInputVal(()=>{ 
        return{
            ...inputVal[name]= value
        }})
   }


   const addData =(e)=>
   {
    e.preventDefault();
    const{username, email, phone, date,password} =inputVal;
    if(username === " "){
        alert("Name field is required");
    }else if(email === " "){
       alert("Email field is required ")
    }else if(phone === " "){
        alert("Email field is required ")
    }else if(date === " "){
        alert("date field is required ")
    }else if(password === " "){
        alert("Password field is required ")
    }else{
        console.log("Data added sucessfully");
        localStorage.setItem("useryoutube",JSON.stringify([...data,inputVal]));
    }

   }
    return(
        <>
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                <ImgR />
                </div>
                
                 <div className="col-md-6">
                 <form className="mt-5 mb-5">
                 <h2 className="pb-3">Registration Form</h2>

                 <div className="form-group row">
                    <div className="col-sm-10 offset-md-1">
                    <input type="name" className="form-control" name="username" 
                    placeholder="Name" onChange={getData}/>
                    </div>
                </div>

                <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="email" className="form-control" name="email" 
                    placeholder="Email" onChange={getData}/>
                    </div>
                </div>

                <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="phone" className="form-control" name="phone" 
                    placeholder="Phone Number" onChange={getData}/>
                    </div>
                </div>

                <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="date" className="form-control" name="date"
                    onChange={getData}/>
                    </div>
                </div>

                <div className="form-group row pt-3">
                    <div className="col-sm-10 offset-md-1">
                    <input type="password" className="form-control" name="password" 
                    placeholder="Password" onChange={getData}/>
                    </div>
                </div>
             
              <div className="form-group row pt-3">
                    <div className="col-sm-12">
                    <button type="submit" className="btn btn-primary btn_clr" 
                    onClick={addData}>Sign in</button>
                    </div>
                </div>
          
          </form>
          <p>Already Have an account <span><NavLink to="/LogIn">Log In</NavLink></span></p>
        </div>
                
      </div>
    </div>
        </>
    )
}

export default SignUp