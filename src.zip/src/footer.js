import React from "react";

function Footer(){
    return(
        <> 
           <div className="container-fluid footer_bg">
              <p>Footer Section</p>
            </div>
        </>
    )
}

export default Footer