import React from "react";

function ImgR(){
    return(
        <>
        <div className="">
            <img src="../img/computer.png"  className="img-fluid"/>
        </div>   
        </>
    )
}

export default ImgR