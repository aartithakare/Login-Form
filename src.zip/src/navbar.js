import React from "react";
import { BrowserRouter, NavLink, Routes, Route } from "react-router-dom";
import Home from './home';
import About from './about';
import Contact from './contact';
import SignUp from "./signIn";
import LogIn from "./logIn";
import Details from "./details";
import './custom.css'

function Navbar(){
    return(
      
        <BrowserRouter>
           <nav className="nav_bg">
                {/* <NavLink to="" className="navbar_clr">Home</NavLink>
                <NavLink to="about" className="navbar_clr">About</NavLink>
                <NavLink to="contact" className="navbar_clr">Contact Us</NavLink>
                <NavLink to="contact" className="navbar_clr">Dashboard</NavLink> */}
                <NavLink to="  " className="navbar_clr">Sign Up</NavLink>
                <NavLink to="logIn" className="navbar_clr">Login</NavLink>
                <NavLink to="details" className="navbar_clr">Details</NavLink>
            </nav>
            <Routes>
                {/* <Route path="/" element={<Home/>} />
                <Route path="about" element={<About/>} />
                <Route path="contact" element={<Contact/>} /> */}
                <Route path="/" element={<SignUp/>} />
                <Route path="logIn" element={<LogIn/>} />
                <Route path="details" element={<Details/>} />
           </Routes>
        </BrowserRouter>
        
    )
}
export default Navbar